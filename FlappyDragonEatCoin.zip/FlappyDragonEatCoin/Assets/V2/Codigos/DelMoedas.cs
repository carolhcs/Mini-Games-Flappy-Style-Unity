﻿using UnityEngine;
using System.Collections;

public class DelMoedas : MonoBehaviour {
	//Esse código desativa o objeto da cena
	void OnCollisionEnter2D(Collision2D coll) {
		//Destruir
		gameObject.SetActive(false);
	}
}
